var temp = prompt("Введите температуру по цельсию C");
alert(9/5*temp+32);