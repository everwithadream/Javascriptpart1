var name;
var admin;
name = "Василий";
admin = name;
alert(admin);